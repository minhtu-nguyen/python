from typing import Literal
from pydantic import BaseModel, Field

Status = Literal["applied", "interview", "offer", "rejected"]


class CompanyIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class ApplicationIn(BaseModel):
    company_id: int = Field(gt=0)
    role: str = Field(min_length=1, max_length=150)
    status: Status = "applied"
