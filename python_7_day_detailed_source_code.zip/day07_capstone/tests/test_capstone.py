from fastapi.testclient import TestClient
from app import app


def test_application_workflow(tmp_path, monkeypatch):
    monkeypatch.setenv("JOBS_DB", str(tmp_path / "jobs.db"))
    client = TestClient(app)

    company = client.post("/companies", json={"name": "Example Co"})
    assert company.status_code == 201
    cid = company.json()["id"]

    application = client.post("/applications", json={
        "company_id": cid, "role": "Python Engineer", "status": "applied"
    })
    assert application.status_code == 201
    aid = application.json()["id"]

    assert len(client.get("/applications", params={"status": "applied"}).json()) == 1
    assert client.patch(f"/applications/{aid}/status", params={"status": "interview"}).status_code == 200
    assert client.get("/stats").json() == {"interview": 1}


def test_missing_company_and_invalid_status(tmp_path, monkeypatch):
    monkeypatch.setenv("JOBS_DB", str(tmp_path / "jobs.db"))
    client = TestClient(app)
    assert client.post("/applications", json={
        "company_id": 999, "role": "Engineer", "status": "applied"
    }).status_code == 404
    assert client.get("/applications", params={"status": "unknown"}).status_code == 422
