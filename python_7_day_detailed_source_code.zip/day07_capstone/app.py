import sqlite3
from fastapi import FastAPI, HTTPException, Query
from db import connect
from schemas import CompanyIn, ApplicationIn, Status

app = FastAPI(title="Job Application Tracker")


@app.post("/companies", status_code=201)
def create_company(body: CompanyIn):
    with connect() as db:
        try:
            cursor = db.execute("INSERT INTO companies(name) VALUES (?)", (body.name,))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Company already exists")
        return {"id": cursor.lastrowid, "name": body.name}


@app.post("/applications", status_code=201)
def create_application(body: ApplicationIn):
    with connect() as db:
        try:
            cursor = db.execute(
                "INSERT INTO applications(company_id, role, status) VALUES (?, ?, ?)",
                (body.company_id, body.role, body.status),
            )
        except sqlite3.IntegrityError:
            raise HTTPException(404, "Company not found")
        return {"id": cursor.lastrowid, **body.model_dump()}


@app.get("/applications")
def list_applications(
    status: Status | None = None,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    query = """SELECT a.id, c.name AS company, a.role, a.status
               FROM applications a JOIN companies c ON c.id=a.company_id"""
    params = []
    if status:
        query += " WHERE a.status = ?"
        params.append(status)
    query += " ORDER BY a.id DESC LIMIT ? OFFSET ?"
    params += [limit, offset]
    with connect() as db:
        return [dict(row) for row in db.execute(query, params)]


@app.patch("/applications/{application_id}/status")
def change_status(application_id: int, status: Status):
    with connect() as db:
        cursor = db.execute("UPDATE applications SET status=? WHERE id=?",
                            (status, application_id))
        if cursor.rowcount == 0:
            raise HTTPException(404, "Application not found")
    return {"id": application_id, "status": status}


@app.get("/stats")
def stats():
    with connect() as db:
        rows = db.execute("SELECT status, COUNT(*) AS count FROM applications GROUP BY status")
        return {row["status"]: row["count"] for row in rows}
