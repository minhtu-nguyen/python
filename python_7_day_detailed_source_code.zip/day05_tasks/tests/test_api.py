import os
from fastapi.testclient import TestClient
from app import app


def test_task_lifecycle(tmp_path, monkeypatch):
    monkeypatch.setenv("TASK_DB", str(tmp_path / "test.db"))
    client = TestClient(app)
    created = client.post("/tasks", json={"title": "Learn FastAPI"})
    assert created.status_code == 201
    task_id = created.json()["id"]
    assert len(client.get("/tasks").json()) == 1
    updated = client.put(f"/tasks/{task_id}", json={"title": "Write tests", "done": True})
    assert updated.status_code == 200
    assert updated.json()["done"] is True
    assert client.get("/tasks", params={"done": True}).json()[0]["id"] == task_id
    assert client.delete(f"/tasks/{task_id}").status_code == 204
    assert client.delete(f"/tasks/{task_id}").status_code == 404


def test_reject_empty_title(tmp_path, monkeypatch):
    monkeypatch.setenv("TASK_DB", str(tmp_path / "test.db"))
    assert TestClient(app).post("/tasks", json={"title": ""}).status_code == 422
