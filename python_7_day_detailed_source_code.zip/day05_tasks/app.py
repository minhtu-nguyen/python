import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from db import connect

app = FastAPI(title="Task Manager")


class TaskInput(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    done: bool = False


class Task(TaskInput):
    id: int


def get_db():
    return connect(os.environ.get("TASK_DB", "tasks.db"))


@app.post("/tasks", response_model=Task, status_code=201)
def create_task(payload: TaskInput):
    with get_db() as db:
        cursor = db.execute("INSERT INTO tasks(title, done) VALUES (?, ?)",
                            (payload.title, int(payload.done)))
        return Task(id=cursor.lastrowid, **payload.model_dump())


@app.get("/tasks", response_model=list[Task])
def list_tasks(done: bool | None = None, limit: int = 50, offset: int = 0):
    if not 1 <= limit <= 100 or offset < 0:
        raise HTTPException(422, "Invalid pagination")
    sql = "SELECT id, title, done FROM tasks"
    params: list = []
    if done is not None:
        sql += " WHERE done = ?"
        params.append(int(done))
    sql += " ORDER BY id LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    with get_db() as db:
        return [Task(id=row["id"], title=row["title"], done=bool(row["done"]))
                for row in db.execute(sql, params)]


@app.put("/tasks/{task_id}", response_model=Task)
def update_task(task_id: int, payload: TaskInput):
    with get_db() as db:
        result = db.execute("UPDATE tasks SET title=?, done=? WHERE id=?",
                            (payload.title, int(payload.done), task_id))
        if result.rowcount == 0:
            raise HTTPException(404, "Task not found")
        return Task(id=task_id, **payload.model_dump())


@app.delete("/tasks/{task_id}", status_code=204)
def delete_task(task_id: int):
    with get_db() as db:
        result = db.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        if result.rowcount == 0:
            raise HTTPException(404, "Task not found")
