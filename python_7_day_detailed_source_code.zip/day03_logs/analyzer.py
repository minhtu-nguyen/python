from collections import Counter
from functools import wraps
from time import perf_counter


def timed(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = perf_counter()
        try:
            return func(*args, **kwargs)
        finally:
            print(f"{func.__name__}: {perf_counter() - start:.4f}s")
    return wrapper


@timed
def analyze(records, slow_threshold: int = 100) -> dict:
    ip_counts = Counter()
    status_counts = Counter()
    slow = 0
    total = 0
    for row in records:
        total += 1
        ip_counts[row["ip"]] += 1
        status_counts[row["status"]] += 1
        slow += row["duration_ms"] >= slow_threshold
    return {"total": total, "top_ips": ip_counts.most_common(5),
            "status_counts": dict(status_counts), "slow_requests": slow}
