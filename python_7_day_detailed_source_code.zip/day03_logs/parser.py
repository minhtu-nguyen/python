from pathlib import Path
from typing import Iterator


def read_logs(path: Path) -> Iterator[dict]:
    with path.open(encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            parts = line.split()
            if len(parts) != 3:
                continue  # In production, record malformed lines in logs.
            ip, status, duration = parts
            try:
                yield {"ip": ip, "status": int(status),
                       "duration_ms": int(duration), "line": line_number}
            except ValueError:
                continue
