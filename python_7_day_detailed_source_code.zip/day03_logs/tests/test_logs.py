from parser import read_logs
from analyzer import analyze


def test_log_analysis(tmp_path):
    path = tmp_path / "requests.log"
    path.write_text("a 200 10\na 500 150\nb 404 25\nmalformed\n", encoding="utf-8")
    result = analyze(read_logs(path), slow_threshold=100)
    assert result["total"] == 3
    assert result["top_ips"][0] == ("a", 2)
    assert result["status_counts"][500] == 1
    assert result["slow_requests"] == 1


def test_empty_file(tmp_path):
    path = tmp_path / "empty.log"
    path.write_text("", encoding="utf-8")
    assert analyze(read_logs(path))["total"] == 0
