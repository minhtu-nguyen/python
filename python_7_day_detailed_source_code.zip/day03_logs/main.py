import argparse
import json
from pathlib import Path
from parser import read_logs
from analyzer import analyze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=Path)
    parser.add_argument("--slow-ms", type=int, default=100)
    args = parser.parse_args()
    print(json.dumps(analyze(read_logs(args.path), args.slow_ms), indent=2))


if __name__ == "__main__":
    main()
