from unittest.mock import Mock
import pytest
from service import normalize_title, create_with_notifier


@pytest.mark.parametrize("raw,expected", [
    ("  Write   tests  ", "Write tests"),
    ("One task", "One task"),
])
def test_normalization(raw, expected):
    assert normalize_title(raw) == expected


def test_empty_title():
    with pytest.raises(ValueError):
        normalize_title("    ")


def test_save_and_notify():
    save = Mock(return_value=42)
    notify = Mock()
    assert create_with_notifier(" New task ", save, notify) == 42
    save.assert_called_once_with("New task")
    notify.assert_called_once_with(42)
