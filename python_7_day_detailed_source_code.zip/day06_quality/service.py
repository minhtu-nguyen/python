import logging

logger = logging.getLogger(__name__)


def normalize_title(title: str) -> str:
    normalized = " ".join(title.split())
    if not normalized:
        raise ValueError("Title is required")
    if len(normalized) > 200:
        raise ValueError("Title too long")
    logger.info("Task title normalized")
    return normalized


def create_with_notifier(title: str, save, notify) -> int:
    clean = normalize_title(title)
    task_id = save(clean)
    notify(task_id)
    return task_id
