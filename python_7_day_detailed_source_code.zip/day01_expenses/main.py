import argparse
from pathlib import Path
from expense import make_expense
from storage import load, save
from reports import by_month, summary, export_csv


def main(argv=None):
    parser = argparse.ArgumentParser(description="Expense tracker")
    parser.add_argument("--file", type=Path, default=Path("expenses.json"))
    subs = parser.add_subparsers(dest="command", required=True)
    add = subs.add_parser("add")
    add.add_argument("--amount", required=True)
    add.add_argument("--category", required=True)
    add.add_argument("--note", default="")
    add.add_argument("--date")
    for name in ("list", "summary", "export"):
        sub = subs.add_parser(name)
        sub.add_argument("--month")
        if name == "export":
            sub.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        rows = load(args.file)
        if args.command == "add":
            rows.append(make_expense(args.amount, args.category, args.note, args.date))
            save(args.file, rows)
            print("Expense added")
        else:
            selected = by_month(rows, args.month)
            if args.command == "list":
                for row in selected:
                    print(f'{row["date"]} {row["category"]}: {row["amount_cents"] / 100:.2f}')
            elif args.command == "summary":
                for category, cents in summary(selected).items():
                    print(f"{category}: {cents / 100:.2f}")
                print(f'TOTAL: {sum(x["amount_cents"] for x in selected) / 100:.2f}')
            else:
                export_csv(selected, args.output)
                print(f"Exported {len(selected)} records")
    except (ValueError, OSError) as exc:
        parser.exit(2, f"Error: {exc}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
