import csv
from collections import defaultdict
from datetime import date
from pathlib import Path


def by_month(rows: list[dict], month: str | None) -> list[dict]:
    if month is None:
        return rows
    if len(month) != 7:
        raise ValueError("Month must be YYYY-MM")
    date.fromisoformat(month + "-01")
    return [row for row in rows if row["date"].startswith(month + "-")]


def summary(rows: list[dict]) -> dict[str, int]:
    totals = defaultdict(int)
    for row in rows:
        totals[row["category"]] += row["amount_cents"]
    return dict(sorted(totals.items()))


def export_csv(rows: list[dict], path: Path) -> None:
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["date", "category", "amount", "note"])
        for row in rows:
            writer.writerow([row["date"], row["category"],
                             f'{row["amount_cents"] / 100:.2f}', row["note"]])
