import tempfile
from pathlib import Path
import pytest
from expense import make_expense, to_cents
from reports import summary, by_month
from storage import load, save
from main import main


def test_amount_validation():
    assert to_cents("12.50") == 1250
    for bad in ("0", "-1", "NaN", "1.234", "oops"):
        with pytest.raises(ValueError):
            to_cents(bad)


def test_report_and_roundtrip(tmp_path):
    rows = [make_expense("10", " FOOD ", when="2026-10-21"),
            make_expense("3", "travel", when="2026-09-01")]
    path = tmp_path / "expenses.json"
    save(path, rows)
    assert load(path) == rows
    assert summary(by_month(rows, "2026-10")) == {"food": 1000}


def test_cli_add(tmp_path):
    path = tmp_path / "data.json"
    assert main(["--file", str(path), "add", "--amount", "2.50",
                 "--category", "food", "--date", "2026-10-21"]) == 0
    assert load(path)[0]["amount_cents"] == 250
