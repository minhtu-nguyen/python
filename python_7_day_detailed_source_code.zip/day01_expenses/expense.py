from datetime import date
from decimal import Decimal, InvalidOperation


def to_cents(text: str) -> int:
    try:
        amount = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError("Amount must be numeric") from exc
    if not amount.is_finite() or amount <= 0 or amount.as_tuple().exponent < -2:
        raise ValueError("Amount must be positive with at most 2 decimal places")
    return int(amount * 100)


def make_expense(amount: str, category: str, note: str = "", when: str | None = None) -> dict:
    category = category.strip().lower()
    if not category:
        raise ValueError("Category is required")
    day = date.fromisoformat(when) if when else date.today()
    return {"date": day.isoformat(), "category": category,
            "amount_cents": to_cents(amount), "note": note.strip()}
