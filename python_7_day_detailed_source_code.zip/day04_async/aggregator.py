import asyncio
import json
import httpx

URLS = [
    "https://jsonplaceholder.typicode.com/todos/1",
    "https://jsonplaceholder.typicode.com/todos/2",
    "https://jsonplaceholder.typicode.com/todos/3",
]


async def fetch_one(client: httpx.AsyncClient, url: str, semaphore: asyncio.Semaphore):
    async with semaphore:
        try:
            response = await client.get(url)
            response.raise_for_status()
            return {"url": url, "data": response.json(), "error": None}
        except (httpx.HTTPError, ValueError) as exc:
            return {"url": url, "data": None, "error": str(exc)}


async def aggregate(urls: list[str], max_concurrent: int = 3) -> list[dict]:
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be positive")
    semaphore = asyncio.Semaphore(max_concurrent)
    async with httpx.AsyncClient(timeout=10.0) as client:
        return await asyncio.gather(
            *(fetch_one(client, url, semaphore) for url in urls)
        )


if __name__ == "__main__":
    print(json.dumps(asyncio.run(aggregate(URLS)), indent=2))
