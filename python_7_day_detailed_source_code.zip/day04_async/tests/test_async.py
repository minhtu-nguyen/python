import asyncio
import httpx
import pytest
from algorithms import two_sum, binary_search
from aggregator import fetch_one, aggregate


def test_algorithms():
    assert two_sum([3, 2, 4], 6) == (1, 2)
    assert binary_search([1, 2, 3], 9) == -1


def test_mocked_async_fetch():
    def handler(request):
        return httpx.Response(200, json={"ok": True})

    async def run():
        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as client:
            result = await fetch_one(client, "https://example.test/data", asyncio.Semaphore(1))
        assert result["data"] == {"ok": True}
        assert result["error"] is None

    asyncio.run(run())


def test_invalid_concurrency():
    with pytest.raises(ValueError):
        asyncio.run(aggregate(["https://example.test"], 0))
