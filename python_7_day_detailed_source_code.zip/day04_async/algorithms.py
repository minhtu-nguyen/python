
def two_sum(numbers: list[int], target: int) -> tuple[int, int] | None:
    seen = {}
    for index, value in enumerate(numbers):
        match = target - value
        if match in seen:
            return seen[match], index
        seen[value] = index
    return None  # O(n) time, O(n) auxiliary space


def binary_search(sorted_numbers: list[int], target: int) -> int:
    left, right = 0, len(sorted_numbers) - 1
    while left <= right:
        mid = (left + right) // 2
        if sorted_numbers[mid] == target:
            return mid
        if sorted_numbers[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1  # O(log n) time
